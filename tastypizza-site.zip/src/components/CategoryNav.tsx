import React, { useRef } from 'react';
import {
  Pizza,
  Flame,
  Sandwich,
  Utensils,
  Disc,
  Layers,
  Box,
  Sparkles,
  Soup,
  CupSoda,
  PlusCircle,
  Info,
  Search,
  X,
} from 'lucide-react';
import { Category, CategoryId, Language } from '../types';

interface CategoryNavProps {
  categories: Category[];
  activeCategory: CategoryId;
  onSelectCategory: (id: CategoryId) => void;
  searchQuery: string;
  onSearchChange: (query: string) => void;
  lang: Language;
  totalResultsCount?: number;
}

const iconMap: Record<string, React.ReactNode> = {
  Pizza: <Pizza className="w-4 h-4" />,
  Flame: <Flame className="w-4 h-4" />,
  Sandwich: <Sandwich className="w-4 h-4" />,
  Utensils: <Utensils className="w-4 h-4" />,
  Disc: <Disc className="w-4 h-4" />,
  Layers: <Layers className="w-4 h-4" />,
  Box: <Box className="w-4 h-4" />,
  Sparkles: <Sparkles className="w-4 h-4" />,
  Soup: <Soup className="w-4 h-4" />,
  CupSoda: <CupSoda className="w-4 h-4" />,
  PlusCircle: <PlusCircle className="w-4 h-4" />,
  Info: <Info className="w-4 h-4" />,
};

export const CategoryNav: React.FC<CategoryNavProps> = ({
  categories,
  activeCategory,
  onSelectCategory,
  searchQuery,
  onSearchChange,
  lang,
  totalResultsCount,
}) => {
  const scrollContainerRef = useRef<HTMLDivElement>(null);
  const isRtl = lang === 'ar';

  return (
    <div className="sticky top-20 z-40 shadow-xl" dir={isRtl ? 'rtl' : 'ltr'}>
      {/* Search & Status Bar */}
      <div className="bg-[#050505] border-b border-white/10 py-2 px-4 sm:px-8">
        <div className="max-w-7xl mx-auto flex flex-col sm:flex-row items-stretch sm:items-center justify-between gap-2.5">
          {/* Search Input in Sleek Interface */}
          <div className="relative flex-1 max-w-md">
            <div className="absolute inset-y-0 left-0 pl-3.5 flex items-center pointer-events-none text-white/40">
              <Search className="w-3.5 h-3.5" />
            </div>
            <input
              type="text"
              value={searchQuery}
              onChange={(e) => onSearchChange(e.target.value)}
              placeholder={
                lang === 'fr'
                  ? 'Rechercher une pizza, un tacos, un panozzo...'
                  : 'ابحث عن بيتزا، طاكوس، باغيتا، بانوزو...'
              }
              className={`w-full bg-white/5 border border-white/10 focus:border-[#C81024] rounded-full py-1.5 ${
                isRtl ? 'pr-3.5 pl-9' : 'pl-9 pr-9'
              } text-xs sm:text-sm text-white placeholder-white/40 transition-all outline-none`}
            />
            {searchQuery && (
              <button
                onClick={() => onSearchChange('')}
                className="absolute inset-y-0 right-0 pr-3 flex items-center text-white/50 hover:text-white cursor-pointer"
                aria-label="Effacer la recherche"
              >
                <X className="w-3.5 h-3.5" />
              </button>
            )}
          </div>

          {/* Quick results label */}
          <div className="flex items-center justify-end text-xs font-semibold text-white/50">
            {searchQuery ? (
              <span className="text-[#FFD800] bg-[#FFD800]/10 px-3 py-0.5 rounded-full border border-[#FFD800]/30 font-bold">
                {lang === 'fr'
                  ? `${totalResultsCount ?? 0} résultat(s)`
                  : `${totalResultsCount ?? 0} نتيجة`}
              </span>
            ) : (
              <span className="text-[11px] uppercase tracking-wider text-white/40">
                {lang === 'fr' ? 'Street Food 100% Frais' : 'طازج ولذيذ'}
              </span>
            )}
          </div>
        </div>
      </div>

      {/* The Sleek Red Category Bar */}
      <nav
        ref={scrollContainerRef}
        className="bg-[#C81024] flex items-center px-6 lg:px-10 gap-6 lg:gap-8 overflow-x-auto no-scrollbar py-3.5"
      >
        {categories.map((cat) => {
          const isActive = activeCategory === cat.id && !searchQuery;
          return (
            <button
              key={cat.id}
              onClick={() => {
                onSelectCategory(cat.id);
                if (searchQuery) onSearchChange('');
              }}
              className={`flex items-center gap-2 whitespace-nowrap font-black uppercase text-xs sm:text-sm tracking-wide cursor-pointer transition-all shrink-0 ${
                isActive
                  ? 'border-b-2 border-white pb-1 text-white opacity-100'
                  : 'opacity-70 hover:opacity-100 text-white'
              }`}
            >
              <span className="shrink-0">
                {iconMap[cat.iconName] || <Utensils className="w-3.5 h-3.5" />}
              </span>
              <span>{lang === 'fr' ? cat.nameFr : cat.nameAr}</span>
            </button>
          );
        })}
      </nav>
    </div>
  );
};
