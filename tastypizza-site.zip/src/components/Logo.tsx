import React from 'react';

/**
 * Logo component - Disabled / Hidden everywhere as per user request ("supprimer le logo par tout")
 */
export const Logo: React.FC = () => null;

export default Logo;
