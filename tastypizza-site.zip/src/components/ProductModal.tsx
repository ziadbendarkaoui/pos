import React from 'react';
import { X, Phone, MessageCircle, Sparkles, Tag, ShieldCheck, Check } from 'lucide-react';
import { MenuItem, Language } from '../types';
import { RESTAURANT_INFO, PIZZA_SUPPLEMENTS } from '../data/menuData';

interface ProductModalProps {
  item: MenuItem | null;
  onClose: () => void;
  lang: Language;
}

export const ProductModal: React.FC<ProductModalProps> = ({
  item,
  onClose,
  lang,
}) => {
  if (!item) return null;

  const isRtl = lang === 'ar';
  const isPizza = item.categoryId === 'pizzas';

  // WhatsApp link with prefilled exact message:
  // "Bonjour Tasty Pizza, je souhaite obtenir des informations sur votre menu."
  const whatsappUrl = `https://wa.me/${RESTAURANT_INFO.whatsapp}?text=${encodeURIComponent(
    lang === 'fr' ? RESTAURANT_INFO.whatsappMessageFr : RESTAURANT_INFO.whatsappMessageAr
  )}`;

  return (
    <div
      className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-4 bg-black/80 backdrop-blur-sm overflow-y-auto"
      onClick={onClose}
    >
      <div
        dir={isRtl ? 'rtl' : 'ltr'}
        onClick={(e) => e.stopPropagation()}
        className="relative w-full max-w-2xl bg-[#141414] border border-white/10 rounded-3xl overflow-hidden shadow-2xl my-auto animate-in zoom-in-95 duration-200"
      >
        {/* Close Button */}
        <button
          onClick={onClose}
          className="absolute top-4 right-4 z-20 w-9 h-9 rounded-full bg-black/70 hover:bg-[#C81024] text-white flex items-center justify-center transition-colors border border-white/10 cursor-pointer"
          aria-label="Fermer"
        >
          <X className="w-4 h-4" />
        </button>

        {/* Modal Image */}
        <div className="relative h-64 sm:h-72 w-full bg-black">
          <img
            src={item.image}
            alt={item.nameFr}
            className="w-full h-full object-cover opacity-85"
          />
          <div className="absolute inset-0 bg-gradient-to-t from-[#141414] via-[#141414]/30 to-transparent" />

          {/* Badges on image */}
          <div className="absolute bottom-4 left-5 flex items-center gap-2">
            {(item.badgeFr || item.badgeAr) && (
              <span className="inline-block px-3 py-1 rounded-full text-[10px] font-black uppercase tracking-wider bg-[#C81024] text-white shadow">
                {lang === 'fr' ? item.badgeFr : item.badgeAr}
              </span>
            )}
            <span className="text-[10px] font-bold uppercase tracking-wider bg-black/70 text-white/70 px-2.5 py-1 rounded-full border border-white/10">
              {item.categoryId.toUpperCase()}
            </span>
          </div>
        </div>

        {/* Modal Body */}
        <div className="p-6 sm:p-8 space-y-6 max-h-[60vh] overflow-y-auto">
          
          {/* Title & Arabic */}
          <div>
            <div className="flex items-baseline justify-between gap-3 mb-1">
              <h3 className="text-2xl sm:text-3xl font-black uppercase text-white tracking-tight">
                {item.nameFr}
              </h3>
              <span className="text-sm font-arabic opacity-40 italic shrink-0">
                {item.nameAr}
              </span>
            </div>
            {item.descriptionFr && (
              <p className="text-xs text-white/50 leading-relaxed mt-2">
                {lang === 'fr' ? item.descriptionFr : item.descriptionAr}
              </p>
            )}
          </div>

          {/* Pricing & Formats breakdown */}
          <div className="bg-black/40 rounded-2xl p-5 border border-white/5 space-y-3">
            <span className="text-[10px] font-black uppercase tracking-widest text-white/40 block">
              {lang === 'fr' ? 'Tarifs officiels en Dirhams (DH)' : 'الأسعار الرسمية بالدرهم المغربي'}
            </span>

            {item.prices ? (
              <div className="grid grid-cols-3 gap-2">
                <div className="bg-white/5 p-3 rounded-xl border border-white/10 text-center">
                  <span className="text-[10px] font-bold uppercase text-white/40 block">
                    {lang === 'fr' ? 'Petite' : 'صغيرة'}
                  </span>
                  <span className="text-lg font-black text-white">
                    {item.prices.petite} <span className="text-xs text-[#FFD800]">DH</span>
                  </span>
                </div>
                <div className="bg-[#C81024]/10 p-3 rounded-xl border border-[#C81024]/30 text-center">
                  <span className="text-[10px] font-bold uppercase text-[#FFD800] block">
                    {lang === 'fr' ? 'Moyenne' : 'متوسطة'}
                  </span>
                  <span className="text-xl font-black text-[#FFD800]">
                    {item.prices.moyenne} <span className="text-xs">DH</span>
                  </span>
                </div>
                <div className="bg-white/5 p-3 rounded-xl border border-white/10 text-center">
                  <span className="text-[10px] font-bold uppercase text-white/40 block">
                    {lang === 'fr' ? 'Grande' : 'كبيرة'}
                  </span>
                  <span className="text-lg font-black text-white">
                    {item.prices.grande} <span className="text-xs text-[#FFD800]">DH</span>
                  </span>
                </div>
              </div>
            ) : (
              <div className="flex items-center justify-between p-1">
                <span className="text-xs font-bold uppercase tracking-wider text-white/60">
                  {lang === 'fr' ? item.formatLabelFr || 'Prix standard' : item.formatLabelAr || 'السعر'}
                </span>
                <span className="text-2xl font-black text-[#FFD800]">
                  {item.singlePrice} <span className="text-sm text-white">DH</span>
                </span>
              </div>
            )}
          </div>

          {/* Supplements breakdown for Pizzas */}
          {isPizza && (
            <div className="space-y-2">
              <span className="text-[10px] font-black uppercase tracking-widest text-white/40 block">
                {lang === 'fr' ? 'Suppléments possibles pour cette pizza' : 'إضافات متوفرة لهذه البيتزا'}
              </span>
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-2 text-xs">
                {PIZZA_SUPPLEMENTS.map((sup, idx) => (
                  <div
                    key={idx}
                    className="p-2.5 rounded-xl bg-white/5 border border-white/5 flex items-center justify-between"
                  >
                    <div className="flex items-center gap-2">
                      <Check className="w-3.5 h-3.5 text-[#FFD800]" />
                      <span className="font-bold text-white text-xs">
                        {lang === 'fr' ? sup.nameFr : sup.nameAr}
                      </span>
                    </div>
                    <span className="font-black text-[#FFD800] text-xs">
                      {sup.prices ? `+${sup.prices.petite}-${sup.prices.grande} DH` : `+${sup.singlePrice} DH`}
                    </span>
                  </div>
                ))}
              </div>
            </div>
          )}

          {/* Information & Contact notice */}
          <div className="p-3.5 rounded-2xl bg-white/[0.03] border border-white/5 flex items-start gap-2.5 text-xs text-white/50">
            <ShieldCheck className="w-4 h-4 text-[#FFD800] shrink-0 mt-0.5" />
            <p className="leading-relaxed text-[11px]">
              {lang === 'fr'
                ? 'Tasty Pizza est un catalogue informatif. Aucune commande ni paiement n’est effectué sur ce site. Pour nous contacter ou vous renseigner sur le menu, utilisez les boutons ci-dessous.'
                : 'موقع تيستي بيتزا هو دليل وقائمة طعام إعلامية فقط. لا تتم أي طلبات أو دفع عبر الموقع. للاستفسار، يرجى الاتصال بنا أو مراسلتنا.'}
            </p>
          </div>

          {/* Quick Contact Actions */}
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 pt-1">
            <a
              href={`tel:${RESTAURANT_INFO.phone}`}
              className="flex items-center justify-center gap-2 py-3 px-4 rounded-xl bg-white/10 hover:bg-white/20 text-white font-bold text-xs uppercase tracking-widest border border-white/10 transition-colors"
            >
              <Phone className="w-3.5 h-3.5 text-[#FFD800]" />
              <span>{lang === 'fr' ? 'Appeler :' : 'اتصل :'} {RESTAURANT_INFO.phoneDisplay}</span>
            </a>

            <a
              href={whatsappUrl}
              target="_blank"
              rel="noopener noreferrer"
              className="flex items-center justify-center gap-2 py-3 px-4 rounded-xl bg-[#C81024] hover:bg-[#a50d1d] text-white font-bold text-xs uppercase tracking-widest transition-colors shadow"
            >
              <MessageCircle className="w-3.5 h-3.5" />
              <span>{lang === 'fr' ? 'WhatsApp Renseignements' : 'واتساب للاستفسار'}</span>
            </a>
          </div>

        </div>
      </div>
    </div>
  );
};
