import React from 'react';
import {
  Phone,
  MessageCircle,
  MapPin,
  Clock,
  ExternalLink,
  Instagram,
  Facebook,
  QrCode,
  Info,
  ShieldCheck,
} from 'lucide-react';
import { Language } from '../types';
import { RESTAURANT_INFO } from '../data/menuData';

interface ContactSectionProps {
  lang: Language;
}

export const ContactSection: React.FC<ContactSectionProps> = ({ lang }) => {
  const isRtl = lang === 'ar';

  const prefilledMessage =
    lang === 'fr' ? RESTAURANT_INFO.whatsappMessageFr : RESTAURANT_INFO.whatsappMessageAr;

  const whatsappUrl = `https://wa.me/${RESTAURANT_INFO.whatsapp}?text=${encodeURIComponent(
    prefilledMessage
  )}`;

  return (
    <section id="contact" className="py-16 sm:py-20 relative bg-[#080808]" dir={isRtl ? 'rtl' : 'ltr'}>
      {/* Background ambient lighting */}
      <div className="absolute top-0 right-1/4 w-96 h-96 bg-[#C81024]/10 rounded-full blur-3xl pointer-events-none" />
      <div className="absolute bottom-0 left-1/4 w-96 h-96 bg-[#FFD800]/10 rounded-full blur-3xl pointer-events-none" />

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10 space-y-12">
        
        {/* Section Header */}
        <div className="text-center max-w-2xl mx-auto space-y-3">
          <div className="inline-flex items-center gap-2 px-3.5 py-1 rounded-full bg-[#C81024]/20 border border-[#C81024]/40 text-[#FFD800] text-[10px] font-black uppercase tracking-wider">
            <MapPin className="w-3.5 h-3.5" />
            <span>{lang === 'fr' ? 'Point de Vente & Échange' : 'موقعنا والتواصل'}</span>
          </div>
          <h2 className="text-3xl sm:text-5xl font-black italic uppercase text-white tracking-tight">
            {lang === 'fr' ? 'Nous Trouver & Nous Contacter' : 'موقعنا والتواصل معنا'}
          </h2>
          <p className="text-xs sm:text-sm text-white/50 leading-relaxed">
            {lang === 'fr'
              ? 'Une question sur notre carte, nos ingrédients ou nos formats ? Venez nous voir ou contactez notre équipe en un clic.'
              : 'هل لديك استفسار حول المنيو أو المكونات أو الأحجام؟ تفضل بزيارتنا أو تواصل مع فريقنا مباشرة.'}
          </p>
        </div>

        {/* 4 Action Buttons requested in specification */}
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-3.5">
          {/* 1. Appeler maintenant */}
          <a
            href={`tel:${RESTAURANT_INFO.phone}`}
            className="flex items-center justify-center gap-3 p-4 rounded-2xl bg-[#FFD800] hover:bg-[#ffe234] text-[#050505] font-black text-xs uppercase tracking-widest shadow-lg transition-transform active:scale-98"
          >
            <Phone className="w-4 h-4 fill-black" />
            <span>{lang === 'fr' ? 'Appeler maintenant' : 'اتصل الآن'}</span>
          </a>

          {/* 2. Contacter sur WhatsApp */}
          <a
            href={whatsappUrl}
            target="_blank"
            rel="noopener noreferrer"
            className="flex items-center justify-center gap-3 p-4 rounded-2xl bg-[#C81024] hover:bg-[#a50d1d] text-white font-black text-xs uppercase tracking-widest shadow-lg transition-transform active:scale-98"
          >
            <MessageCircle className="w-4 h-4 fill-white" />
            <span>{lang === 'fr' ? 'Contacter sur WhatsApp' : 'تواصل عبر واتساب'}</span>
          </a>

          {/* 3. Ouvrir dans Google Maps */}
          <a
            href={RESTAURANT_INFO.mapsUrl}
            target="_blank"
            rel="noopener noreferrer"
            className="flex items-center justify-center gap-3 p-4 rounded-2xl bg-white/10 hover:bg-white/20 text-white font-bold text-xs uppercase tracking-widest border border-white/10 transition-transform active:scale-98"
          >
            <MapPin className="w-4 h-4 text-[#FFD800]" />
            <span>{lang === 'fr' ? 'Ouvrir dans Maps' : 'فتح في Google Maps'}</span>
          </a>

          {/* 4. Voir Instagram */}
          <a
            href={RESTAURANT_INFO.instagram}
            target="_blank"
            rel="noopener noreferrer"
            className="flex items-center justify-center gap-3 p-4 rounded-2xl bg-white/5 hover:bg-white/10 text-white font-bold text-xs uppercase tracking-widest border border-white/10 shadow transition-transform active:scale-98"
          >
            <Instagram className="w-4 h-4 text-[#FFD800]" />
            <span>{lang === 'fr' ? 'Voir Instagram' : 'زيارة إنستغرام'}</span>
          </a>
        </div>

        {/* Notice on WhatsApp purpose as required */}
        <div className="p-3 rounded-2xl bg-white/[0.02] border border-white/5 text-center text-[11px] text-white/50 max-w-2xl mx-auto flex items-center justify-center gap-2">
          <Info className="w-3.5 h-3.5 text-[#FFD800] shrink-0" />
          <span>
            {lang === 'fr'
              ? 'Note : Le bouton WhatsApp sert uniquement à demander des renseignements sur la carte ou nos horaires.'
              : 'تنبيه : زر واتساب مخصص فقط لطلب المعلومات والاستفسار عن المنيو ومواعيد العمل.'}
          </span>
        </div>

        {/* Detailed Grid: Practical Info + Maps + QR Code */}
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-stretch">
          
          {/* Practical Info Card (Phone, Hours, Address, Socials) */}
          <div className="lg:col-span-5 bg-[#141414] rounded-3xl p-6 sm:p-8 border border-white/5 flex flex-col justify-between space-y-6 shadow-xl">
            <div className="space-y-6">
              <h3 className="text-xl font-bold uppercase text-white tracking-tight border-b border-white/5 pb-4">
                {lang === 'fr' ? 'Informations Pratiques' : 'معلومات التواصل والمواعيد'}
              </h3>

              {/* Phone */}
              <div className="flex items-start gap-4">
                <div className="w-11 h-11 rounded-2xl bg-[#C81024]/20 flex items-center justify-center text-[#FFD800] shrink-0">
                  <Phone className="w-5 h-5" />
                </div>
                <div>
                  <p className="text-[10px] font-bold text-white/40 uppercase tracking-widest">
                    {lang === 'fr' ? 'Téléphone & WhatsApp' : 'الهاتف والواتساب'}
                  </p>
                  <a
                    href={`tel:${RESTAURANT_INFO.phone}`}
                    className="text-xl font-black text-[#FFD800] hover:underline"
                  >
                    {RESTAURANT_INFO.phoneDisplay}
                  </a>
                  <p className="text-[11px] text-white/40 mt-0.5">
                    {lang === 'fr' ? 'Ligne directe du restaurant' : 'الخط المباشر للمطعم'}
                  </p>
                </div>
              </div>

              {/* Opening Hours */}
              <div className="flex items-start gap-4">
                <div className="w-11 h-11 rounded-2xl bg-white/5 flex items-center justify-center text-[#FFD800] shrink-0">
                  <Clock className="w-5 h-5" />
                </div>
                <div>
                  <p className="text-[10px] font-bold text-white/40 uppercase tracking-widest">
                    {lang === 'fr' ? 'Horaires d’ouverture' : 'أوقات العمل'}
                  </p>
                  <p className="text-base font-bold text-white">
                    {lang === 'fr' ? RESTAURANT_INFO.openingHoursFr : RESTAURANT_INFO.openingHoursAr}
                  </p>
                  <span className="inline-block mt-1 px-2.5 py-0.5 rounded-full text-[10px] font-bold uppercase bg-emerald-500/10 text-emerald-400 border border-emerald-500/20">
                    {lang === 'fr' ? '● Ouvert 7j/7' : '● مفتوح طيلة أيام الأسبوع'}
                  </span>
                </div>
              </div>

              {/* Address */}
              <div className="flex items-start gap-4">
                <div className="w-11 h-11 rounded-2xl bg-white/5 flex items-center justify-center text-[#C81024] shrink-0">
                  <MapPin className="w-5 h-5" />
                </div>
                <div>
                  <p className="text-[10px] font-bold text-white/40 uppercase tracking-widest">
                    {lang === 'fr' ? 'Adresse' : 'العنوان'}
                  </p>
                  <p className="text-xs font-semibold text-white/80">
                    {lang === 'fr' ? RESTAURANT_INFO.addressFr : RESTAURANT_INFO.addressAr}
                  </p>
                  <p className="text-[11px] text-white/40 mt-1 italic">
                    {lang === 'fr'
                      ? 'Localisation précise mise à jour à l’ouverture officielle'
                      : 'سيتم تحديث الموقع الدقيق فور الإعلان الرسمي'}
                  </p>
                </div>
              </div>

              {/* Social Networks Links */}
              <div className="pt-4 border-t border-white/5">
                <p className="text-[10px] font-bold text-white/40 uppercase tracking-widest mb-3">
                  {lang === 'fr' ? 'Suivez Tasty Pizza' : 'تابعنا على مواقع التواصل'}
                </p>
                <div className="flex items-center gap-2">
                  <a
                    href={RESTAURANT_INFO.instagram}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="flex items-center gap-2 px-3 py-1.5 rounded-xl bg-white/5 hover:bg-white/10 text-white text-xs font-bold transition-colors"
                  >
                    <Instagram className="w-3.5 h-3.5 text-[#FFD800]" />
                    <span>Instagram</span>
                  </a>
                  <a
                    href={RESTAURANT_INFO.facebook}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="flex items-center gap-2 px-3 py-1.5 rounded-xl bg-white/5 hover:bg-white/10 text-white text-xs font-bold transition-colors"
                  >
                    <Facebook className="w-3.5 h-3.5 text-[#FFD800]" />
                    <span>Facebook</span>
                  </a>
                  <a
                    href={whatsappUrl}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="flex items-center gap-2 px-3 py-1.5 rounded-xl bg-white/5 hover:bg-white/10 text-white text-xs font-bold transition-colors"
                  >
                    <MessageCircle className="w-3.5 h-3.5 text-[#25D366]" />
                    <span>WhatsApp</span>
                  </a>
                </div>
              </div>
            </div>

            {/* Quick QR Code Pill */}
            <div className="bg-black/40 rounded-2xl p-4 border border-white/5 flex items-center justify-between gap-4">
              <div className="space-y-1">
                <span className="text-xs font-bold text-white flex items-center gap-1.5">
                  <QrCode className="w-4 h-4 text-[#FFD800]" />
                  <span>{lang === 'fr' ? 'Scannez pour nous écrire' : 'امسح للتواصل'}</span>
                </span>
                <p className="text-[11px] text-white/40">
                  {lang === 'fr' ? 'Accès direct WhatsApp 06 29 90 80 01' : 'تواصل فوري على الواتساب'}
                </p>
              </div>
              {/* Graphic QR Code Simulation / SVG */}
              <div className="w-14 h-14 bg-white p-1.5 rounded-xl flex items-center justify-center shrink-0">
                <svg viewBox="0 0 100 100" className="w-full h-full">
                  {/* Outer corner squares */}
                  <rect x="5" y="5" width="30" height="30" fill="#050505" />
                  <rect x="10" y="10" width="20" height="20" fill="white" />
                  <rect x="15" y="15" width="10" height="10" fill="#C81024" />

                  <rect x="65" y="5" width="30" height="30" fill="#050505" />
                  <rect x="70" y="10" width="20" height="20" fill="white" />
                  <rect x="75" y="15" width="10" height="10" fill="#C81024" />

                  <rect x="5" y="65" width="30" height="30" fill="#050505" />
                  <rect x="10" y="70" width="20" height="20" fill="white" />
                  <rect x="15" y="75" width="10" height="10" fill="#C81024" />

                  {/* QR Data Pattern */}
                  <rect x="45" y="10" width="10" height="10" fill="#050505" />
                  <rect x="45" y="30" width="10" height="10" fill="#050505" />
                  <rect x="15" y="45" width="10" height="10" fill="#050505" />
                  <rect x="35" y="45" width="10" height="10" fill="#C81024" />
                  <rect x="55" y="45" width="10" height="10" fill="#050505" />
                  <rect x="75" y="45" width="10" height="10" fill="#050505" />
                  <rect x="45" y="65" width="10" height="10" fill="#050505" />
                  <rect x="65" y="65" width="10" height="10" fill="#050505" />
                  <rect x="85" y="75" width="10" height="10" fill="#050505" />
                  <rect x="55" y="85" width="10" height="10" fill="#050505" />
                </svg>
              </div>
            </div>

          </div>

          {/* Google Maps Location Preview */}
          <div className="lg:col-span-7 bg-[#141414] rounded-3xl border border-white/5 overflow-hidden flex flex-col shadow-xl">
            {/* Top Bar of Map Container */}
            <div className="p-4 bg-black/80 border-b border-white/10 flex items-center justify-between">
              <div className="flex items-center gap-2">
                <span className="w-3 h-3 rounded-full bg-[#C81024]" />
                <span className="text-xs sm:text-sm font-bold text-white uppercase tracking-wider">
                  {lang === 'fr' ? 'Emplacement Google Maps' : 'موقع المطعم على الخريطة'}
                </span>
              </div>

              <a
                href={RESTAURANT_INFO.mapsUrl}
                target="_blank"
                rel="noopener noreferrer"
                className="inline-flex items-center gap-1.5 text-xs font-bold text-[#FFD800] hover:underline"
              >
                <span>{lang === 'fr' ? 'Agrandir le plan' : 'تكبير الخريطة'}</span>
                <ExternalLink className="w-3.5 h-3.5" />
              </a>
            </div>

            {/* Map Area */}
            <div className="relative flex-1 min-h-[340px] sm:min-h-[400px] bg-neutral-950 flex items-center justify-center overflow-hidden">
              {/* Stylized Urban Map Background Graphic */}
              <div className="absolute inset-0 opacity-30 bg-[radial-gradient(#ffffff1a_1px,transparent_1px)] [background-size:16px_16px]" />
              
              {/* Street grid stylized lines */}
              <svg className="absolute inset-0 w-full h-full stroke-white/10 fill-none" xmlns="http://www.w3.org/2000/svg">
                <path d="M0 80 Q 200 120 400 60 T 800 100" strokeWidth="6" />
                <path d="M120 0 L 120 500" strokeWidth="4" />
                <path d="M360 0 L 360 500" strokeWidth="5" />
                <path d="M600 0 L 600 500" strokeWidth="3" />
                <path d="M0 240 L 800 240" strokeWidth="5" />
                <path d="M0 380 L 800 380" strokeWidth="4" />
              </svg>

              {/* Pin Centered on Map */}
              <div className="relative z-10 flex flex-col items-center animate-bounce">
                <div className="w-14 h-14 rounded-full bg-[#C81024] border-4 border-white shadow-2xl flex items-center justify-center text-white">
                  <MapPin className="w-7 h-7 text-[#FFD800] fill-[#FFD800]" />
                </div>
                <div className="mt-2 bg-[#050505]/95 backdrop-blur-md px-4 py-2 rounded-xl border border-white/20 shadow-2xl text-center">
                  <p className="font-display font-black text-sm text-white uppercase tracking-wider">
                    Tasty Pizza
                  </p>
                  <p className="text-[11px] text-[#FFD800] font-bold">
                    Pizza & Street Food
                  </p>
                  <p className="text-[10px] text-neutral-400 mt-0.5">
                    06 29 90 80 01
                  </p>
                </div>
              </div>

              {/* Overlay button in map */}
              <div className="absolute bottom-4 left-4 right-4 sm:right-auto z-20">
                <a
                  href={RESTAURANT_INFO.mapsUrl}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="flex items-center justify-center gap-2 px-5 py-3 rounded-xl bg-[#C81024] hover:bg-[#A00B1A] text-white font-extrabold text-xs uppercase tracking-wider shadow-lg transition-colors"
                >
                  <MapPin className="w-4 h-4 text-[#FFD800]" />
                  <span>{lang === 'fr' ? 'Ouvrir dans Google Maps' : 'فتح في Google Maps'}</span>
                </a>
              </div>
            </div>

            {/* Bottom info strip */}
            <div className="p-3 bg-black/60 border-t border-white/10 text-center text-xs text-neutral-400">
              <span>
                {lang === 'fr'
                  ? 'Pour commander au comptoir ou vous renseigner, retrouvez-nous aux heures d’ouverture.'
                  : 'للطلب مباشرة عند الكاونتر أو الاستفسار، نرحب بكم خلال أوقات العمل الرسمية.'}
              </span>
            </div>
          </div>

        </div>

      </div>
    </section>
  );
};
