import React from 'react';
import { Phone, Clock, MapPin, Instagram, Facebook, MessageCircle, ArrowUp } from 'lucide-react';
import { Language } from '../types';
import { RESTAURANT_INFO } from '../data/menuData';

interface FooterProps {
  lang: Language;
  onScrollTop: () => void;
}

export const Footer: React.FC<FooterProps> = ({ lang, onScrollTop }) => {
  const isRtl = lang === 'ar';

  const prefilledMessage =
    lang === 'fr' ? RESTAURANT_INFO.whatsappMessageFr : RESTAURANT_INFO.whatsappMessageAr;

  const whatsappUrl = `https://wa.me/${RESTAURANT_INFO.whatsapp}?text=${encodeURIComponent(
    prefilledMessage
  )}`;

  return (
    <footer className="bg-[#050505] text-white border-t border-white/10 pt-12 pb-24 sm:pb-8" dir={isRtl ? 'rtl' : 'ltr'}>
      <div className="max-w-7xl mx-auto px-6 lg:px-10 space-y-8">
        
        {/* Main Footer Row */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-12 gap-8">
          
          {/* Col 1: Brand & Slogan */}
          <div className="lg:col-span-5 space-y-3">
            <span className="text-2xl font-black uppercase tracking-wider text-white inline-block">
              TASTY <span className="text-[#C81024]">PIZZA</span>
            </span>
            
            <p className="text-lg font-black text-[#FFD800] uppercase tracking-wide">
              {lang === 'fr' ? '« Du bon. Du frais. Du Tasty. »' : '« لذيذ. طازج. تيستي. »'}
            </p>

            <p className="text-xs text-white/50 max-w-md leading-relaxed">
              {lang === 'fr'
                ? 'Pizzas artisanales, street food généreuse et recettes originales préparées à la minute au Maroc.'
                : 'وجهتكم المفضلة لأشهى البيتزا الإيطالية والستريت فود المحضر في حينه بمكونات طازجة 100%.'}
            </p>

            <div className="flex items-center gap-3 pt-1">
              <a
                href={RESTAURANT_INFO.instagram}
                target="_blank"
                rel="noopener noreferrer"
                className="w-9 h-9 rounded-full bg-white/5 border border-white/10 hover:border-white/30 flex items-center justify-center text-white/70 hover:text-white transition-colors"
                aria-label="Instagram"
              >
                <Instagram className="w-4 h-4" />
              </a>
              <a
                href={RESTAURANT_INFO.facebook}
                target="_blank"
                rel="noopener noreferrer"
                className="w-9 h-9 rounded-full bg-white/5 border border-white/10 hover:border-white/30 flex items-center justify-center text-white/70 hover:text-white transition-colors"
                aria-label="Facebook"
              >
                <Facebook className="w-4 h-4" />
              </a>
              <a
                href={whatsappUrl}
                target="_blank"
                rel="noopener noreferrer"
                className="w-9 h-9 rounded-full bg-white/5 border border-white/10 hover:border-white/30 flex items-center justify-center text-white/70 hover:text-white transition-colors"
                aria-label="WhatsApp"
              >
                <MessageCircle className="w-4 h-4" />
              </a>
            </div>
          </div>

          {/* Col 2: Direct Contact */}
          <div className="lg:col-span-4 space-y-3">
            <h4 className="text-xs font-black uppercase text-white tracking-widest pb-1 border-b border-white/10">
              {lang === 'fr' ? 'Coordonnées & Horaires' : 'بيانات التواصل'}
            </h4>

            <div className="space-y-2 text-xs text-white/70">
              <div className="flex items-center gap-2">
                <Phone className="w-3.5 h-3.5 text-[#FFD800] shrink-0" />
                <a
                  href={`tel:${RESTAURANT_INFO.phone}`}
                  className="font-bold text-white hover:text-[#FFD800] transition-colors"
                >
                  {RESTAURANT_INFO.phoneDisplay}
                </a>
              </div>

              <div className="flex items-center gap-2">
                <Clock className="w-3.5 h-3.5 text-[#FFD800] shrink-0" />
                <span>
                  {lang === 'fr' ? RESTAURANT_INFO.openingHoursFr : RESTAURANT_INFO.openingHoursAr}
                </span>
              </div>

              <div className="flex items-center gap-2">
                <MapPin className="w-3.5 h-3.5 text-[#C81024] shrink-0" />
                <span>
                  {lang === 'fr' ? RESTAURANT_INFO.addressFr : RESTAURANT_INFO.addressAr}
                </span>
              </div>
            </div>
          </div>

          {/* Col 3: Legal & Back to top */}
          <div className="lg:col-span-3 space-y-3 flex flex-col justify-between">
            <div>
              <h4 className="text-xs font-black uppercase text-white tracking-widest pb-1 border-b border-white/10 mb-2">
                {lang === 'fr' ? 'Catalogue Informatif' : 'دليل إعلامي'}
              </h4>
              <p className="text-[11px] text-white/40 leading-relaxed">
                {lang === 'fr'
                  ? 'Ce site est un catalogue digital informatif. Aucune commande ni paiement en ligne.'
                  : 'موقع إعلامي لعرض الأسعار والوصفات الرسمية فقط.'}
              </p>
            </div>

            <button
              onClick={onScrollTop}
              className="inline-flex items-center gap-2 self-start px-3.5 py-1.5 rounded-full bg-white/5 hover:bg-white/15 text-white/70 hover:text-white text-[11px] font-bold uppercase tracking-wider transition-colors border border-white/10 cursor-pointer"
            >
              <ArrowUp className="w-3.5 h-3.5 text-[#FFD800]" />
              <span>{lang === 'fr' ? 'Haut de page' : 'للأعلى'}</span>
            </button>
          </div>

        </div>

        {/* Bottom Minimal Copyright Strip as in Sleek Interface */}
        <div className="pt-6 border-t border-white/10 flex flex-col sm:flex-row items-center justify-between gap-4 text-[10px] uppercase tracking-widest text-white/40">
          <p>
            © {new Date().getFullYear()} Tasty Pizza. All rights reserved.
          </p>
          <div className="flex items-center gap-6">
            <span className="text-[#FFD800]">Maroc</span>
            <span>Street Food</span>
            <span>100% Frais</span>
          </div>
        </div>

      </div>
    </footer>
  );
};
