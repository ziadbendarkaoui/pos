import React, { useState, useMemo, useEffect } from 'react';
import {
  Flame,
  Pizza,
  Sparkles,
  LayoutGrid,
  Table as TableIcon,
  ShieldAlert,
  Search,
  CheckCircle2,
  HeartHandshake,
  Clock,
  Award,
} from 'lucide-react';
import { Header } from './components/Header';
import { Hero } from './components/Hero';
import { StreetTicker } from './components/StreetTicker';
import { CategoryNav } from './components/CategoryNav';
import { ProductCard } from './components/ProductCard';
import { PizzaTableView } from './components/PizzaTableView';
import { SupplementsSection } from './components/SupplementsSection';
import { CombosSection } from './components/CombosSection';
import { ProductModal } from './components/ProductModal';
import { ContactSection } from './components/ContactSection';
import { Footer } from './components/Footer';
import { QuickMobileBar } from './components/QuickMobileBar';
import { CATEGORIES, MENU_ITEMS } from './data/menuData';
import { CategoryId, Language, MenuItem } from './types';

export default function App() {
  const [lang, setLang] = useState<Language>('fr');
  const [activeCategory, setActiveCategory] = useState<CategoryId>('pizzas');
  const [searchQuery, setSearchQuery] = useState('');
  const [activeSection, setActiveSection] = useState('accueil');
  const [selectedProduct, setSelectedProduct] = useState<MenuItem | null>(null);
  const [pizzaViewMode, setPizzaViewMode] = useState<'cards' | 'table'>('cards');

  // Update HTML document direction and language attribute when lang changes
  useEffect(() => {
    document.documentElement.lang = lang;
    document.documentElement.dir = lang === 'ar' ? 'rtl' : 'ltr';
  }, [lang]);

  // Filter products based on search query or active category
  const filteredProducts = useMemo(() => {
    if (searchQuery.trim()) {
      const q = searchQuery.toLowerCase().trim();
      return MENU_ITEMS.filter(
        (item) =>
          item.nameFr.toLowerCase().includes(q) ||
          item.nameAr.includes(q) ||
          item.descriptionFr?.toLowerCase().includes(q) ||
          item.descriptionAr?.includes(q) ||
          item.categoryId.toLowerCase().includes(q)
      );
    }
    return MENU_ITEMS.filter((item) => item.categoryId === activeCategory);
  }, [searchQuery, activeCategory]);

  const currentCategoryObj = useMemo(() => {
    return CATEGORIES.find((c) => c.id === activeCategory) || CATEGORIES[0];
  }, [activeCategory]);

  const allPizzas = useMemo(() => {
    return MENU_ITEMS.filter((item) => item.categoryId === 'pizzas');
  }, []);

  const handleNavigateSection = (sectionId: string) => {
    setActiveSection(sectionId);
    if (sectionId === 'accueil') {
      window.scrollTo({ top: 0, behavior: 'smooth' });
    } else if (sectionId === 'catalogue' || sectionId === 'produits') {
      const el = document.getElementById('catalogue-section');
      if (el) {
        el.scrollIntoView({ behavior: 'smooth' });
      }
    } else {
      const el = document.getElementById(sectionId);
      if (el) {
        el.scrollIntoView({ behavior: 'smooth' });
      }
    }
  };

  const isRtl = lang === 'ar';

  return (
    <div className={`min-h-screen bg-[#050505] text-white flex flex-col font-body ${isRtl ? 'font-arabic' : ''}`}>
      
      {/* Top Header */}
      <Header
        lang={lang}
        onToggleLang={setLang}
        onNavigateSection={handleNavigateSection}
        activeSection={activeSection}
      />

      {/* Main Content */}
      <main className="flex-1">
        {/* Hero Banner with Pizza Image & Badges */}
        <Hero
          lang={lang}
          onDiscoverClick={() => handleNavigateSection('catalogue')}
          onContactClick={() => handleNavigateSection('contact')}
        />

        {/* Dynamic Street Food Animated Marquee */}
        <StreetTicker lang={lang} />

        {/* Editorial Value Section: "L'Esprit Tasty Pizza" */}
        <section className="py-12 bg-[#0d0d0d] border-b border-white/5" dir={isRtl ? 'rtl' : 'ltr'}>
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
              
              <div className="flex items-center gap-4 p-5 rounded-3xl bg-[#141414] border border-white/5 hover:border-white/20 transition-all">
                <div className="w-11 h-11 rounded-2xl bg-[#C81024]/20 flex items-center justify-center text-[#FFD800] shrink-0">
                  <Flame className="w-5 h-5" />
                </div>
                <div>
                  <h4 className="font-bold uppercase text-white text-xs tracking-wider">
                    {lang === 'fr' ? 'Pâte Artisanale' : 'عجينة طازجة يومية'}
                  </h4>
                  <p className="text-[11px] text-white/40 mt-0.5">
                    {lang === 'fr' ? 'Pétrie chaque matin avec passion' : 'تعجن يدوياً كل صباح بإتقان'}
                  </p>
                </div>
              </div>

              <div className="flex items-center gap-4 p-5 rounded-3xl bg-[#141414] border border-white/5 hover:border-white/20 transition-all">
                <div className="w-11 h-11 rounded-2xl bg-[#FFD800]/20 flex items-center justify-center text-[#FFD800] shrink-0">
                  <Sparkles className="w-5 h-5" />
                </div>
                <div>
                  <h4 className="font-bold uppercase text-white text-xs tracking-wider">
                    {lang === 'fr' ? '100% Mozzarella' : 'جبن موزاريلا صافي'}
                  </h4>
                  <p className="text-[11px] text-white/40 mt-0.5">
                    {lang === 'fr' ? 'Pur lait étirée au four chaud' : 'موزاريلا مطاطية تذوب في الفم'}
                  </p>
                </div>
              </div>

              <div className="flex items-center gap-4 p-5 rounded-3xl bg-[#141414] border border-white/5 hover:border-white/20 transition-all">
                <div className="w-11 h-11 rounded-2xl bg-emerald-500/20 flex items-center justify-center text-emerald-400 shrink-0">
                  <Award className="w-5 h-5" />
                </div>
                <div>
                  <h4 className="font-bold uppercase text-white text-xs tracking-wider">
                    {lang === 'fr' ? 'Viandes de Choix' : 'لحوم طازجة ومختارة'}
                  </h4>
                  <p className="text-[11px] text-white/40 mt-0.5">
                    {lang === 'fr' ? 'Bœuf & poulet mariné maison' : 'كفتة عجل طازجة ودجاج متبل'}
                  </p>
                </div>
              </div>

              <div className="flex items-center gap-4 p-5 rounded-3xl bg-[#141414] border border-white/5 hover:border-white/20 transition-all">
                <div className="w-11 h-11 rounded-2xl bg-[#C81024]/20 flex items-center justify-center text-[#FFD800] shrink-0">
                  <Clock className="w-5 h-5" />
                </div>
                <div>
                  <h4 className="font-bold uppercase text-white text-xs tracking-wider">
                    {lang === 'fr' ? 'Préparé Minute' : 'تحضير فوري عند الطلب'}
                  </h4>
                  <p className="text-[11px] text-white/40 mt-0.5">
                    {lang === 'fr' ? 'Chaud, croustillant et généreux' : 'ساخن، مقرمش وكبير'}
                  </p>
                </div>
              </div>

            </div>
          </div>
        </section>

        {/* Catalogue Anchor & Section */}
        <section id="catalogue-section" className="relative py-8 sm:py-12">
          
          {/* Section Heading */}
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 mb-6" dir={isRtl ? 'rtl' : 'ltr'}>
            <div className="flex flex-col md:flex-row md:items-end justify-between gap-4">
              <div>
                <span className="text-[10px] font-black tracking-widest text-[#FFD800] uppercase block mb-1">
                  {lang === 'fr' ? 'CATALOGUE DES PRODUITS' : 'قائمة المأكولات الرسمية'}
                </span>
                <h2 className="text-3xl sm:text-4xl font-black italic uppercase text-white tracking-tight">
                  {searchQuery ? (
                    lang === 'fr' ? 'Résultats de Recherche' : 'نتائج البحث'
                  ) : (
                    lang === 'fr' ? currentCategoryObj.nameFr : currentCategoryObj.nameAr
                  )}
                  <span className="text-xs font-normal not-italic opacity-40 ml-3 tracking-widest uppercase">
                    / Tasty Pizza
                  </span>
                </h2>
              </div>

              {/* Informative Catalogue Badge Reassurance */}
              <div className="flex items-center gap-2 px-4 py-1.5 rounded-full bg-white/5 border border-white/10 text-xs text-white/50">
                <CheckCircle2 className="w-3.5 h-3.5 text-[#FFD800]" />
                <span className="text-[11px]">
                  {lang === 'fr'
                    ? 'Catalogue informatif – Tarifs officiels en Dirhams (DH)'
                    : 'دليل أسعار إعلامي – الأسعار الرسمية بالدرهم'}
                </span>
              </div>
            </div>
          </div>

          {/* Sticky Horizontal Categories Nav & Instant Search */}
          <CategoryNav
            categories={CATEGORIES}
            activeCategory={activeCategory}
            onSelectCategory={(id) => {
              setActiveCategory(id);
              // Scroll to start of catalogue smoothly
              const catSection = document.getElementById('catalogue-section');
              if (catSection) {
                const yOffset = -120;
                const y = catSection.getBoundingClientRect().top + window.pageYOffset + yOffset;
                window.scrollTo({ top: y, behavior: 'smooth' });
              }
            }}
            searchQuery={searchQuery}
            onSearchChange={setSearchQuery}
            lang={lang}
            totalResultsCount={filteredProducts.length}
          />

          {/* Products & Views Container */}
          <div id="produits" className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 pt-8 space-y-12" dir={isRtl ? 'rtl' : 'ltr'}>
            
            {/* View Switcher only for Pizzas when not searching */}
            {!searchQuery && activeCategory === 'pizzas' && (
              <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 p-4 rounded-3xl bg-[#141414] border border-white/5 shadow-lg">
                <div className="flex items-center gap-2.5">
                  <span className="w-8 h-8 rounded-full bg-[#C81024]/20 flex items-center justify-center text-[#FFD800]">
                    <Pizza className="w-4 h-4" />
                  </span>
                  <span className="text-xs sm:text-sm font-bold text-white/90">
                    {lang === 'fr'
                      ? '12 Recettes au choix – 3 diamètres (Petite, Moyenne, Grande)'
                      : '12 نوع بيتزا شهية – متوفرة بـ 3 أحجام (صغيرة، متوسطة، كبيرة)'}
                  </span>
                </div>

                <div className="flex items-center bg-black/40 p-1 rounded-full border border-white/10 self-start sm:self-auto">
                  <button
                    onClick={() => setPizzaViewMode('cards')}
                    className={`flex items-center gap-1.5 px-4 py-1.5 rounded-full text-[11px] font-black uppercase tracking-wider transition-all cursor-pointer ${
                      pizzaViewMode === 'cards'
                        ? 'bg-[#C81024] text-white shadow'
                        : 'text-white/40 hover:text-white'
                    }`}
                  >
                    <LayoutGrid className="w-3.5 h-3.5" />
                    <span>{lang === 'fr' ? 'Cartes' : 'بطاقات'}</span>
                  </button>

                  <button
                    onClick={() => setPizzaViewMode('table')}
                    className={`flex items-center gap-1.5 px-4 py-1.5 rounded-full text-[11px] font-black uppercase tracking-wider transition-all cursor-pointer ${
                      pizzaViewMode === 'table'
                        ? 'bg-[#C81024] text-white shadow'
                        : 'text-white/40 hover:text-white'
                    }`}
                  >
                    <TableIcon className="w-3.5 h-3.5" />
                    <span>{lang === 'fr' ? 'Tableau' : 'جدول'}</span>
                  </button>
                </div>
              </div>
            )}

            {/* Special Category Renderers */}
            {!searchQuery && activeCategory === 'supplements' ? (
              <SupplementsSection lang={lang} />
            ) : !searchQuery && activeCategory === 'informations' ? (
              <CombosSection lang={lang} />
            ) : !searchQuery && activeCategory === 'pizzas' && pizzaViewMode === 'table' ? (
              <div className="space-y-8">
                <PizzaTableView
                  pizzas={allPizzas}
                  lang={lang}
                  onViewDetails={setSelectedProduct}
                />
                <SupplementsSection lang={lang} />
              </div>
            ) : (
              /* Standard Responsive Product Grid: 3 cols desktop, 2 cols tablet, 1 col mobile */
              <div className="space-y-10">
                {filteredProducts.length > 0 ? (
                  <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                    {filteredProducts.map((item) => {
                      const cat = CATEGORIES.find((c) => c.id === item.categoryId);
                      const catName = lang === 'fr' ? cat?.nameFr || '' : cat?.nameAr || '';
                      return (
                        <ProductCard
                          key={item.id}
                          item={item}
                          lang={lang}
                          categoryName={catName}
                          onViewDetails={setSelectedProduct}
                        />
                      );
                    })}
                  </div>
                ) : (
                  <div className="py-16 text-center bg-neutral-900/50 rounded-3xl border border-white/10 p-8 space-y-4 max-w-md mx-auto">
                    <div className="w-14 h-14 rounded-full bg-[#C81024]/20 border border-[#C81024]/40 flex items-center justify-center text-[#FFD800] mx-auto">
                      <Search className="w-6 h-6" />
                    </div>
                    <h3 className="text-xl font-display font-extrabold uppercase text-white">
                      {lang === 'fr' ? 'Aucun produit trouvé' : 'لم يتم العثور على أي منتج'}
                    </h3>
                    <p className="text-xs text-neutral-400">
                      {lang === 'fr'
                        ? 'Essayez de rechercher un autre nom ou réinitialisez le filtre pour voir toutes nos recettes.'
                        : 'جرب البحث باسم آخر أو أعد تعيين شريط البحث لتصفح جميع الوصفات.'}
                    </p>
                    <button
                      onClick={() => setSearchQuery('')}
                      className="px-5 py-2.5 rounded-xl bg-[#C81024] text-white font-bold text-xs uppercase tracking-wider"
                    >
                      {lang === 'fr' ? 'Réinitialiser la recherche' : 'مسح البحث'}
                    </button>
                  </div>
                )}

                {/* If on Pizzas category cards view, also append the supplements block underneath */}
                {!searchQuery && activeCategory === 'pizzas' && pizzaViewMode === 'cards' && (
                  <div className="pt-8 border-t border-white/10">
                    <SupplementsSection lang={lang} />
                  </div>
                )}
              </div>
            )}

            {/* If on any street food category, show a quick reminder banner for Formules */}
            {!searchQuery &&
              activeCategory !== 'informations' &&
              activeCategory !== 'supplements' && (
                <div className="p-5 sm:p-6 rounded-3xl bg-[#141414] border border-white/5 flex flex-col sm:flex-row items-center justify-between gap-4 shadow-xl">
                  <div className="flex items-center gap-4">
                    <div className="w-12 h-12 rounded-2xl bg-[#C81024] flex items-center justify-center text-white font-black text-base shrink-0 shadow">
                      +15<span className="text-[10px] ml-0.5">DH</span>
                    </div>
                    <div>
                      <h4 className="font-bold uppercase text-white text-sm sm:text-base tracking-tight">
                        {lang === 'fr'
                          ? 'Envie d’un menu complet ?'
                          : 'تريد وجبة متكاملة مع المشروب والفريت ؟'}
                      </h4>
                      <p className="text-xs text-white/50 mt-0.5">
                        {lang === 'fr'
                          ? 'Frites dorées croustillantes + Boisson fraîche 33 cl pour seulement 15 DH.'
                          : 'بطاطس مقلية + مشروب منعش 33 سل فقط بـ 15 درهم زيادة.'}
                      </p>
                    </div>
                  </div>

                  <button
                    onClick={() => setActiveCategory('informations')}
                    className="px-5 py-2.5 rounded-full bg-white/10 hover:bg-[#C81024] text-white text-xs font-bold uppercase tracking-wider transition-colors border border-white/10 whitespace-nowrap cursor-pointer"
                  >
                    {lang === 'fr' ? 'Voir les formules' : 'عرض تفاصيل العروض'}
                  </button>
                </div>
              )}

          </div>
        </section>

        {/* Informative Notice Strip before Contact */}
        <section className="py-6 bg-black border-y border-white/10">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-center text-xs text-neutral-400 space-y-1">
            <p className="font-bold text-neutral-300">
              {lang === 'fr'
                ? 'ℹ️ Site informatif officiel de la pizzeria Tasty Pizza — Maroc'
                : 'ℹ️ الموقع الرسمي الإخباري لمطعم تيستي بيتزا — المغرب'}
            </p>
            <p>
              {lang === 'fr'
                ? 'Pour déguster nos pizzas, baguettas, tacos et panozzos, rendez-vous directement en restaurant ou contactez-nous par téléphone au 06 29 90 80 01.'
                : 'لتذوق أطباقنا اللذيذة، تفضل بزيارة المطعم مباشرة أو اتصل بنا هاتفياً على الرقم 06 29 90 80 01.'}
            </p>
          </div>
        </section>

        {/* Section "Nous Trouver" & Contact */}
        <ContactSection lang={lang} />
      </main>

      {/* Footer */}
      <Footer
        lang={lang}
        onScrollTop={() => window.scrollTo({ top: 0, behavior: 'smooth' })}
      />

      {/* Product Details Modal */}
      <ProductModal
        item={selectedProduct}
        onClose={() => setSelectedProduct(null)}
        lang={lang}
      />

      {/* Mobile Floating Quick Bar (Phone, WhatsApp, Menu Jump) */}
      <QuickMobileBar
        lang={lang}
        onNavigateSection={handleNavigateSection}
      />

    </div>
  );
}
